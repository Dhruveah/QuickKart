﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace QuickKartCoreMVCApp.Models
{
    public class Products
    {   
        [DisplayName("Category Id")]
        [Required(ErrorMessage = "mandatory.")]
        public byte? CategoryId { get; set; }
        
        [Required(ErrorMessage = "mandatory.")]
        public decimal Price { get; set; }

        [DisplayName("Product Id")]
        [Required(ErrorMessage = "mandatory.")]
        public string ProductId { get; set; }

        [DisplayName("Product Name")]
        [Required(ErrorMessage = "mandatory.")]
        [StringLength(100,MinimumLength=3)]
        public string ProductName { get; set; }

        [DisplayName("Quantity Avaialble")]
        [Required(ErrorMessage = "mandatory.")]
        [Range(1,int.MaxValue,ErrorMessage ="Value Must be greater than zero")]
        public int QuantityAvailable { get; set; }
    }
}
