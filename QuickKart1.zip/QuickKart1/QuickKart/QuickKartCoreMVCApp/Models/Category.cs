﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QuickKartCoreMVCApp.Models
{
    public class Category
    {
       
        public byte CategoryId { get; set; }
        
        [Required(ErrorMessage = "mandatory.")]
        public string CategoryName { get; set; }
    }
}
