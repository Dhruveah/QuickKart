﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuickKartCoreMVCApp.Models;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickKartCoreMVCApp.Controllers
{
    public class CategoryController : Controller
    {
        private readonly IMapper _mapper;
        private readonly QuickKartContext _context;
        QuickKartRepository repObj;

        public CategoryController(QuickKartContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
            repObj = new QuickKartRepository(_context);
        }
            // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddCategory()
        {
            return View();
        }

        public IActionResult SaveAddedCategory(Models.Category category)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.AddCategory(_mapper.Map<Categories>(category));
                    if (status)
                        return RedirectToAction("ViewCategories");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("AddCategory", category);
        }
        public IActionResult ViewCategories()
        {
            var lstEntityProducts = repObj.GetCategories();
            List<Models.Category> lstModelProducts = new List<Models.Category>();
            foreach (var Category in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Category>(Category));
            }
            return View(lstModelProducts);
        }

        public IActionResult UpdateCategory(Models.Category CategoryObj)
        {
            return View(CategoryObj);
        }

        public IActionResult SaveUpdatedCategory(Models.Category category)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.UpdateCategory(_mapper.Map<Categories>(category));
                    if (status)
                        return RedirectToAction("ViewCategories");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("UpdateProduct", category);
        }


        public IActionResult DeleteCategory(Models.Category category)
        {
            return View(category);
        }
        [HttpPost]
        public IActionResult SaveDeletion(Models.Category category)
        {
            bool status = false;
            try
            {
                status = repObj.DeleteCategory(_mapper.Map<Categories>(category));
                if (status)
                    return RedirectToAction("ViewCategories");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }

        }
    }
}
