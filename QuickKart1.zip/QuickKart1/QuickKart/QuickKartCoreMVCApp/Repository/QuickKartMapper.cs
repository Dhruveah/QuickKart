﻿using AutoMapper;
using QuickKartDataAccessLayer.Models;

namespace QuickKartCoreMVCApp.Repository
{
    public class QuickKartMapper:Profile
    {
        public QuickKartMapper()
        {
            
            CreateMap<Products, Models.Products>();
            CreateMap<Categories,Models.Category>();
            CreateMap<Models.Products, Products>();
            CreateMap<Models.Category, Categories>();
            CreateMap<Models.PurchaseDetails, PurchaseDetails>();
        }
    }
}
